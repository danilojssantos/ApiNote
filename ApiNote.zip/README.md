APi 

<span>

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" width="40" height="40"  />

<img src="https://raw.githubusercontent.com/SLAriosi/svgTools/main/SQLite.png" width="40" height="40"  />
<img src="https://raw.githubusercontent.com/SLAriosi/svgTools/main/NodeJS.png" width="40" height="40"  />



</span>

## Dependências

**bcryptjs -> `"^2.4.3"`** 

**express -> `"^4.18.3"`** 

**sqlite  -> `"^5.1.1"`** 

**sqlite3 -> `"^5.1.7"`**

## Dependências de Desenvolvimento

**nodemon -> `"^3.1.0"`** 

##  Knex
### `iniciando` 
```javascript
 npx knex init
```

### `Criando Tabela` 
```javascript
 npx knex migrate:make createNotes
```







